﻿
namespace HW_CPS_HSEZoo
{
    // ServiceCollection services = new ServiceCollection();

    public class MainClass 
    {
        public static void Main (string[] args) 
        {
            UIZoo.Menu();
        }
    }
}