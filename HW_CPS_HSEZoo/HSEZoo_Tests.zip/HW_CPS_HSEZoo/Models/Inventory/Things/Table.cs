﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_CPS_HSEZoo.Models.Inventory.Things
{
    public class Table : Thing
    {
        public Table(int num) { _number = num; }
    }
}
