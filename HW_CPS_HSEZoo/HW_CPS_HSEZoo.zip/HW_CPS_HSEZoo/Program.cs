﻿namespace HseZoo
{
    class Program 
    { 
        public static void Main(string[] args)
        {
            Console.WriteLine("start");
        }
    }
}