﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_CPS_HSEZoo
{
    internal interface IAlive
    {
        string Food { get; }
    }
}
