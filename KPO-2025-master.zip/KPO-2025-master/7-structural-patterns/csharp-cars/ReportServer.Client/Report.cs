namespace ReportServer.Client;

public class Report
{
    public string Title { get; set; } = string.Empty;
    public string Contents { get; set; } = string.Empty;
} 