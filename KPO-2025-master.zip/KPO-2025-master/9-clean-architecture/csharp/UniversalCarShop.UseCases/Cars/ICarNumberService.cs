namespace UniversalCarShop.UseCases.Cars;

public interface ICarNumberService
{
    int GetNextNumber();
}

