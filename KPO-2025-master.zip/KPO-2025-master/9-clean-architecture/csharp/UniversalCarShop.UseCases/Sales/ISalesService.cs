using UniversalCarShop.Entities.Common;

namespace UniversalCarShop.UseCases.Sales;

public interface ISalesService
{
    void SellCars();
}

