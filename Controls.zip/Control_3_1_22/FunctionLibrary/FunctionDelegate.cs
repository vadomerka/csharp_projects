﻿namespace FunctionLibrary
{
    public delegate double FunctionDelegate(double x);
}
