﻿namespace FunctionLibrary
{
    public interface IFunction
    {
        double Calculate(double x);
    }
}
